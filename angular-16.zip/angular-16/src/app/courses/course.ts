export interface Course {
  id?: string;
  title: string;
  price: number;
}
